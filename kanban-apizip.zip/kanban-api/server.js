const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
// const bcrypt = require('bcrypt'); // <== ELIMINADO
 
const app = express();
const PORT = 3000;
// const SALT_ROUNDS = 10; // <== ELIMINADO

// --- Middlewares ---
app.use(cors());
app.use(express.json());

// --- Conexión a MongoDB ---
mongoose.connect('mongodb://mongo:27017/todoDB')
  .then(() => console.log('Conectado a MongoDB (todoDB)...'))
  .catch(err => console.error('No se pudo conectar a MongoDB:', err));

// --- MODELO 1: Board (Tablero) ---
const boardSchema = new mongoose.Schema({
  id_tablero: { type: Number, required: true, unique: true },
  password_tablon: { type: String, required: true }
});
const Board = mongoose.model('Board', boardSchema); 

// --- MODELO 2: Card (Tarjeta) ---
const cardSchema = new mongoose.Schema({
  id_tablero: { type: Number, required: true }, 
  title: String,
  description: String,
  status: {
    type: String,
    enum: ['ideas', 'pendiente', 'haciendo', 'hecho'],
    default: 'ideas'
  }
});
const Card = mongoose.model('Card', cardSchema); 

// --- Servir los archivos estáticos del Frontend ---
app.use(express.static(path.join(__dirname, 'ToDo-')));

// --- RUTAS DE API PARA TABLEROS (Boards) ---

// POST: Crear un nuevo tablero (SIN BCRYPT)
app.post('/api/board/create', async (req, res) => {
  try {
    const { password, confirmPassword } = req.body;

    if (!password || !confirmPassword) {
      return res.status(400).json({ message: 'Faltan campos de contraseña' });
    }
    if (password !== confirmPassword) {
      return res.status(400).json({ message: 'Las contraseñas no coinciden' });
    }
    
    // 1. Generar un ID de tablero único
    let newId;
    let boardExists = true;
    while (boardExists) {
      newId = Math.floor(1000 + Math.random() * 9000);
      boardExists = await Board.findOne({ id_tablero: newId });
    }

    // 2. Encriptar la contraseña  <== (SECCIÓN ELIMINADA)
    // const hashedPassword = await bcrypt.hash(password, SALT_ROUNDS);

    // 3. Crear y guardar el nuevo tablero (con contraseña en texto plano)
    const newBoard = new Board({
      id_tablero: newId,
      password_tablon: password // <== CAMBIADO (guarda texto plano)
    });
    await newBoard.save();

    // 4. Devolver el ID al usuario
    res.status(201).json({ id_tablero: newId });

  } catch (err) {
    console.error("¡ERROR en /api/board/create!:", err); // Log para Docker
    res.status(500).json({ message: err.message });
  }
});

// POST: Unirse a un tablero existente (SIN BCRYPT)
app.post('/api/board/join', async (req, res) => {
  try { // <== Añadido try/catch por si acaso
    const { id_tablero, password } = req.body;

    // 1. Buscar el tablero
    const board = await Board.findOne({ id_tablero: id_tablero });
    if (!board) {
      return res.status(404).json({ message: 'ID de tablero no encontrado' });
    }

    // 2. Comparar la contraseña (comparación simple de texto)
    // const isMatch = await bcrypt.compare(password, board.password_tablon); // <== ELIMINADO
    if (password !== board.password_tablon) { // <== CAMBIADO (comparación simple)
      return res.status(401).json({ message: 'Contraseña incorrecta' });
    }

    // 3. Éxito
    res.status(200).json({ message: 'Acceso concedido', id_tablero: board.id_tablero });

  } catch (err) {
    console.error("¡ERROR en /api/board/join!:", err); // Log para Docker
    res.status(500).json({ message: err.message });
  }
});


// --- RUTAS DE API PARA TARJETAS (Cards) ---
// (Estas rutas no cambian, pégalas tal cual)

// GET: Obtener todas las tarjetas DE UN TABLERO específico
app.get('/api/cards/:boardId', async (req, res) => {
  try {
    const cards = await Card.find({ id_tablero: req.params.boardId });
    res.json(cards);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// POST: Crear una nueva tarjeta EN UN TABLERO específico
app.post('/api/cards/:boardId', async (req, res) => {
  const card = new Card({
    title: req.body.title,
    description: req.body.description,
    status: 'ideas', 
    id_tablero: req.params.boardId 
  });

  try {
    const newCard = await card.save();
    res.status(201).json(newCard);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// PUT: Mover/Actualizar una tarjeta 
app.put('/api/cards/:cardId', async (req, res) => {
  try {
    const updatedCard = await Card.findByIdAndUpdate(
      req.params.cardId,
      { status: req.body.status }, 
      { new: true }
    );
    res.json(updatedCard);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
});

// DELETE: Eliminar una tarjeta 
app.delete('/api/cards/:cardId', async (req, res) => {
  try {
    await Card.findByIdAndDelete(req.params.cardId);
    res.json({ message: 'Tarjeta eliminada' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
});

// --- Rutas de archivos HTML ---
app.get('/board', (req, res) => {
  res.sendFile(path.join(__dirname, 'ToDo-', 'src', 'board.html'));
});
app.get('/join', (req, res) => {
  res.sendFile(path.join(__dirname, 'ToDo-', 'src', 'jocBoard.html'));
});
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'ToDo-', 'login.html'));
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
