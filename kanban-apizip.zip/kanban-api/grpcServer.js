const grpc = require('@grpc/grpc-js');
const protoLoader = require('@grpc/proto-loader');
const mongoose = require('mongoose');
const path = require('path');

// 1. Cargar el archivo .proto
const PROTO_PATH = path.join(__dirname, 'kanban.proto');
const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true
});
const kanbanProto = grpc.loadPackageDefinition(packageDefinition).kanban;

// 2. Conexión a MongoDB (Igual que antes)
mongoose.connect('mongodb://mongo:27017/todoDB')
  .then(() => console.log('Conectado a MongoDB para gRPC...'))
  .catch(err => console.error('Error Mongo:', err));

// --- MODELOS MONGOOSE (Los mismos que ya tenías) ---
const boardSchema = new mongoose.Schema({
  id_tablero: { type: Number, required: true, unique: true },
  password_tablon: { type: String, required: true }
});
const Board = mongoose.model('Board', boardSchema);

const cardSchema = new mongoose.Schema({
  id_tablero: { type: Number, required: true },
  title: String,
  description: String,
  status: { type: String, default: 'ideas' }
});
const Card = mongoose.model('Card', cardSchema);

// 3. Implementación de las funciones gRPC

// Crear Tablero
const CreateBoard = async (call, callback) => {
  const password = call.request.password;
  
  // Generar ID random
  let newId = Math.floor(1000 + Math.random() * 9000);
  
  try {
    const newBoard = new Board({
      id_tablero: newId,
      password_tablon: password
    });
    await newBoard.save();
    
    // Responder al cliente
    callback(null, { id_tablero: newId, message: "Tablero creado con éxito" });
  } catch (err) {
    callback({
      code: grpc.status.INTERNAL,
      details: "Error creando tablero: " + err.message
    });
  }
};

// Crear Tarjeta
const CreateCard = async (call, callback) => {
  const { id_tablero, title, description } = call.request;
  
  try {
    const newCard = new Card({
      id_tablero,
      title,
      description,
      status: 'ideas'
    });
    const savedCard = await newCard.save();
    
    callback(null, {
      id: savedCard._id.toString(),
      title: savedCard.title,
      description: savedCard.description,
      status: savedCard.status
    });
  } catch (err) {
    callback({ code: grpc.status.INTERNAL, details: err.message });
  }
};

// Leer Tarjetas (Get)
const GetCards = async (call, callback) => {
  const id_tablero = call.request.id_tablero;
  try {
    const cards = await Card.find({ id_tablero: id_tablero });
    
    // Mapear al formato del proto
    const cardsProto = cards.map(c => ({
      id: c._id.toString(),
      title: c.title,
      description: c.description,
      status: c.status
    }));
    
    callback(null, { cards: cardsProto });
  } catch (err) {
    callback({ code: grpc.status.INTERNAL, details: err.message });
  }
};

// Actualizar Tarjeta
const UpdateCardStatus = async (call, callback) => {
  const { id, status } = call.request;
  try {
    const updated = await Card.findByIdAndUpdate(id, { status: status }, { new: true });
    if (!updated) return callback({ code: grpc.status.NOT_FOUND, details: "Tarjeta no encontrada" });
    
    callback(null, {
      id: updated._id.toString(),
      title: updated.title,
      description: updated.description,
      status: updated.status
    });
  } catch (err) {
    callback({ code: grpc.status.INTERNAL, details: err.message });
  }
};

// Borrar Tarjeta
const DeleteCard = async (call, callback) => {
  const id = call.request.id;
  try {
    await Card.findByIdAndDelete(id);
    callback(null, { message: "Tarjeta eliminada correctamente" });
  } catch (err) {
    callback({ code: grpc.status.INTERNAL, details: err.message });
  }
};

// 4. Iniciar el Servidor
const server = new grpc.Server();
server.addService(kanbanProto.KanbanService.service, {
  CreateBoard,
  CreateCard,
  GetCards,
  UpdateCardStatus,
  DeleteCard
});

server.bindAsync('0.0.0.0:50051', grpc.ServerCredentials.createInsecure(), () => {
  console.log('Servidor gRPC corriendo en puerto 50051');
  server.start();
});
